import express from 'express'
import axios from 'axios'

export const jiraRouter = express.Router()

// In-memory session store: sessionId -> { baseUrl, authHeader, acceptanceField? }
const sessions = new Map<string, { baseUrl: string; authHeader: string; acceptanceField?: string }>()

function generateSessionId() {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`
}

function extractPlainTextFromJiraDescription(desc: any): string {
  if (!desc) return ''
  if (typeof desc === 'string') return desc

  let result = ''
  function walk(node: any) {
    if (!node) return
    if (Array.isArray(node)) {
      node.forEach(walk)
      return
    }
    if (typeof node === 'string') {
      result += node
      return
    }
    if (node.type === 'text' && typeof node.text === 'string') {
      result += node.text
      return
    }
    if (node.content) {
      walk(node.content)
      if (node.type === 'paragraph' || node.type === 'heading') result += '\n\n'
    }
  }
  walk(desc)
  return result.trim()
}

function getTextFromNode(node: any): string {
  if (!node) return ''
  if (typeof node === 'string') return node
  let s = ''
  if (node.type === 'text' && typeof node.text === 'string') return node.text
  if (node.text && typeof node.text === 'string') return node.text
  if (node.content && Array.isArray(node.content)) {
    for (const child of node.content) s += getTextFromNode(child)
  }
  return s
}

function extractAcceptanceCriteria(desc: any): string {
  if (!desc) return ''

  // If plain string description, try regex and simple heuristics
  if (typeof desc === 'string') {
    // Common markers
    const patterns = [
      /Acceptance Criteria[:\-\s]*([\s\S]*)/i,
      /AC[:\-\s]*([\s\S]*)/i
    ]
    for (const p of patterns) {
      const m = desc.match(p)
      if (m && m[1]) return m[1].trim()
    }

    // Heuristic: find a line that mentions 'acceptance' and collect following list lines
    const lines = desc.split(/\r?\n/)
    for (let i = 0; i < lines.length; i++) {
      if (/acceptance/i.test(lines[i])) {
        const collected: string[] = []
        for (let j = i + 1; j < lines.length; j++) {
          const line = lines[j].trim()
          if (line === '') {
            // stop on double newline
            if (collected.length > 0) break
            else continue
          }
          if (/^#{1,6}\s/.test(line)) break // heading
          if (/^[-*\u2022]\s+/.test(line) || /^\d+\./.test(line) || line.startsWith('-') || line.startsWith('*')) {
            collected.push(line.replace(/^[-*\u2022]\s+/, ''))
            continue
          }
          // stop if next section seems like another heading
          if (/^[A-Z][A-Za-z0-9\s]{0,60}:$/.test(line)) break
          collected.push(line)
        }
        if (collected.length) return collected.join('\n')
      }
    }
    return ''
  }

  // If Jira ADF (object), traverse content to find a heading that contains 'acceptance'
  try {
    const content = desc.content || []
    let startIndex = -1
    for (let i = 0; i < content.length; i++) {
      const node = content[i]
      const text = getTextFromNode(node) || ''
      if (/acceptance criteria|acceptance|ac[:\s]/i.test(text)) {
        startIndex = i
        break
      }
    }
    if (startIndex === -1) return ''

    const pieces: string[] = []
    for (let k = startIndex + 1; k < content.length; k++) {
      const node = content[k]
      if (!node) continue
      // stop at next heading
      if (node.type && node.type.startsWith('heading')) break
      if (node.type === 'paragraph') {
        const t = getTextFromNode(node)
        if (t) pieces.push(t)
      } else if (node.type === 'bulletList' || node.type === 'orderedList') {
        // collect list items
        const listItems: string[] = []
        for (const li of (node.content || [])) {
          const text = getTextFromNode(li)
          if (text) listItems.push(text.trim())
        }
        if (listItems.length) pieces.push(listItems.map((x, idx) => `- ${x}`).join('\n'))
      } else {
        const t = getTextFromNode(node)
        if (t) pieces.push(t)
      }
    }
    return pieces.join('\n').trim()
  } catch (e) {
    return ''
  }
}

// POST /connect - validate Jira credentials and create a session
jiraRouter.post('/connect', async (req, res) => {
  try {
    const { baseUrl, email, apiToken } = req.body

    if (!baseUrl || !email || !apiToken) {
      return res.status(400).json({ error: 'baseUrl, email and apiToken are required' })
    }

    const authHeader = `Basic ${Buffer.from(`${email}:${apiToken}`).toString('base64')}`

    // ✅ Test credentials by calling /myself
    const resp = await axios.get(`${baseUrl.replace(/\/+$/, '')}/rest/api/3/myself`, {
      headers: {
        Authorization: authHeader,
        Accept: 'application/json',
      },
      timeout: 5000,
    })

    if (resp.status !== 200) {
      return res.status(401).json({ error: 'Invalid credentials or unauthorized' })
    }

    const sessionId = generateSessionId()
    const cleanBase = baseUrl.replace(/\/+$/, '')

    // Attempt to discover a custom field named 'Acceptance Criteria' (case-insensitive)
    let acceptanceField: string | undefined = undefined
    try {
      const fieldsResp = await axios.get(`${cleanBase}/rest/api/3/field`, {
        headers: { Authorization: authHeader, Accept: 'application/json' },
        timeout: 5000
      })
      const allFields: any[] = fieldsResp.data || []
      const match = allFields.find(f => typeof f.name === 'string' && /acceptance criteria|acceptance/i.test(f.name))
      if (match && match.id) acceptanceField = match.id
    } catch (e: any) {
      // non-fatal: field discovery failed — we'll fallback to description parsing later
      console.debug('Could not discover acceptance criteria field on connect:', e?.response?.data || e?.message || e)
    }

    sessions.set(sessionId, { baseUrl: cleanBase, authHeader, acceptanceField })

    res.json({ sessionId, acceptanceField })
  } catch (error: any) {
    console.error('Error in /jira/connect', error.response?.data || error.message)
    res.status(500).json({ error: error.message || 'Internal server error' })
  }
})

// ✅ Middleware to resolve session from header
jiraRouter.use((req, res, next) => {
  if (req.path === '/connect') return next()

  const sessionId = req.header('x-session-id') || req.query.sessionId
  if (!sessionId || typeof sessionId !== 'string') {
    return res.status(400).json({ error: 'Missing x-session-id header or sessionId query param' })
  }

  const session = sessions.get(sessionId)
  if (!session) {
    return res.status(401).json({ error: 'Invalid or expired session' })
  }

  ;(req as any).jiraSession = session
  next()
})

jiraRouter.get('/stories', async (req, res) => {
  try {
    const session = (req as any).jiraSession as { baseUrl: string; authHeader: string }

    // Accept projectKey as query param, fallback to 'RAG'
    const projectKey = (req.query.projectKey as string) || 'RAG'
    const jql = `project = ${projectKey} AND issuetype = Story ORDER BY created DESC`

    // ✅ Jira Cloud now requires POST to /rest/api/3/search/jql
    const url = `${session.baseUrl}/rest/api/3/search/jql`

    const body = {
      jql,
      fields: ['summary'],
      maxResults: 50
    }

    const resp = await axios.post(url, body, {
      headers: {
        Authorization: session.authHeader,
        Accept: 'application/json',
        'Content-Type': 'application/json'
      },
      timeout: 8000
    })

    const issues = resp.data.issues || []
    const stories = issues.map((it: any) => ({
      key: it.key,
      id: it.id,
      summary: it.fields?.summary || ''
    }))

    res.json({ stories })
  } catch (error: any) {
    const errResp = error?.response
    console.error('Error fetching stories from Jira:', errResp?.status, errResp?.data || error.message)
    res.status(errResp?.status || 500).json({
      error: 'Failed to fetch stories from Jira',
      details: errResp?.data || { message: error.message }
    })
  }
})

// ✅ GET /stories/:key - fetch details of a story
jiraRouter.get('/stories/:key', async (req, res) => {
  try {
    const session = (req as any).jiraSession as { baseUrl: string; authHeader: string }
    const { key } = req.params
    if (!key) {
      return res.status(400).json({ error: 'Missing issue key' })
    }

    const url = `${session.baseUrl}/rest/api/3/issue/${encodeURIComponent(key)}`
    // Request summary, description and the discovered acceptance field (if any)
    const sessionAny = session as any
    const acceptanceFieldId = sessionAny.acceptanceField
    const fieldsParam = acceptanceFieldId ? `summary,description,${acceptanceFieldId}` : 'summary,description'

    const resp = await axios.get(url, {
      headers: {
        Authorization: session.authHeader,
        Accept: 'application/json',
      },
      params: {
        fields: fieldsParam,
      },
      timeout: 8000,
    })

    const fields = resp.data.fields || {}
    const summary = fields.summary || ''
    const descriptionRaw = fields.description
    const descriptionText = extractPlainTextFromJiraDescription(descriptionRaw)

    // Prefer a discovered custom field (if present in session)
    let acceptanceCriteria = ''
    if (acceptanceFieldId && fields[acceptanceFieldId]) {
      const rawACField = fields[acceptanceFieldId]
      // rawACField could be a string or ADF-like object
      if (typeof rawACField === 'string') {
        acceptanceCriteria = rawACField
      } else {
        // try structured extraction
        acceptanceCriteria = extractAcceptanceCriteria(rawACField) || extractPlainTextFromJiraDescription(rawACField)
      }
    }

    // Fallbacks: ADF or plain-text in description
    if (!acceptanceCriteria) {
      acceptanceCriteria = extractAcceptanceCriteria(descriptionRaw)
      if (!acceptanceCriteria) {
        const acMatch = descriptionText.match(/Acceptance Criteria[:\-\s]*([\s\S]*)/i)
        if (acMatch) acceptanceCriteria = acMatch[1].trim()
      }
    }

    res.json({ key, summary, description: descriptionText, acceptanceCriteria })
  } catch (error: any) {
    const errResp = error?.response
    console.error('Error fetching story details from Jira:', errResp?.status, errResp?.data || error.message)
    res.status(errResp?.status || 500).json({
      error: 'Failed to fetch story details from Jira',
      details: errResp?.data || { message: error.message },
    })
  }
})
