import { GenerateRequest, GenerateResponse } from './types'

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8081/api'

export async function generateTests(request: GenerateRequest): Promise<GenerateResponse> {
  try {
    const response = await fetch(`${API_BASE_URL}/generate-tests`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(request),
    })

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: 'Unknown error' }))
      throw new Error(errorData.error || `HTTP error! status: ${response.status}`)
    }

    const data: GenerateResponse = await response.json()
    return data
  } catch (error) {
    console.error('Error generating tests:', error)
    throw error instanceof Error ? error : new Error('Unknown error occurred')
  }
}

// --- Jira integration helpers ---
export type JiraConnectRequest = {
  baseUrl: string
  email: string
  apiToken: string
}

export type JiraStoryItem = {
  key: string
  id: string
  summary: string
}

export type JiraStoryDetail = {
  key: string
  summary: string
  description: string
  acceptanceCriteria?: string
}

export async function connectJira(payload: JiraConnectRequest): Promise<{ sessionId: string }> {
  const response = await fetch(`${API_BASE_URL}/jira/connect`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  })

  if (!response.ok) {
    const err = await response.json().catch(() => ({ error: 'Unknown error' }))
    throw new Error(err.error || `HTTP error ${response.status}`)
  }

  return response.json()
}

export async function listJiraStories(sessionId: string): Promise<{ stories: JiraStoryItem[] }> {
  const response = await fetch(`${API_BASE_URL}/jira/stories`, {
    method: 'GET',
    headers: { 'x-session-id': sessionId }
  })

  if (!response.ok) {
    const err = await response.json().catch(() => ({ error: 'Unknown error' }))
    throw new Error(err.error || `HTTP error ${response.status}`)
  }

  return response.json()
}

export async function getJiraStory(sessionId: string, key: string): Promise<JiraStoryDetail> {
  const response = await fetch(`${API_BASE_URL}/jira/stories/${encodeURIComponent(key)}`, {
    method: 'GET',
    headers: { 'x-session-id': sessionId }
  })

  if (!response.ok) {
    const err = await response.json().catch(() => ({ error: 'Unknown error' }))
    throw new Error(err.error || `HTTP error ${response.status}`)
  }

  return response.json()
}